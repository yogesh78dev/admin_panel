<!doctype html>

<html>

<head>

    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body>



    <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- <div id="main" class="row"> -->

        <?php echo $__env->yieldContent('content'); ?>

    <!-- </div> -->



    <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



    </div>

</body>

</html><?php /**PATH D:\xampp\htdocs\demo\example-app\resources\views/layouts/default.blade.php ENDPATH**/ ?>