@extends('layouts.default')
@section('content')
<div class="content-wrapper">
    <div class="container-xxl flex-grow-1 container-p-y row">
        <div class="card">
            <form method="post" action="">
                <div class="card-body">
                    <div class="mb-3 row">
                        <label for="html5-text-input" class="col-md-2 col-form-label">User Name</label>
                        <div class="col-md-10">
                            <input class="form-control" type="text" name="name" value="" id="user_name" />
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="html5-text-input" class="col-md-2 col-form-label">Email</label>
                        <div class="col-md-10">
                            <input class="form-control" type="email" name="email" value="" id="email" />
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="html5-text-input" class="col-md-2 col-form-label">Contact No</label>
                        <div class="col-md-10">
                            <input class="form-control" type="" name="phone_no" value="" id="phone_no" />
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="" class="col-md-2 form-label">Select Role</label>
                        <div class="col-md-10">
                            <select class="form-select" id="role_name">
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="html5-text-input" class="col-md-2 col-form-label">Address</label>
                        <div class="col-md-10">
                            <input class="form-control" type="" name="address" value="" id="address" />
                        </div>
                    </div>
                    <div class="mb-3 row">
                        <label for="formFile" class="col-md-2 form-label">Image</label>
                        <div class="col-md-10">
                            <input class="form-control" name="image" type="file" id="formFile" />
                        </div>
                    </div>
                    <div class="form-check form-switch mb-3 row">
                        <label class="form-check-label" for="flexSwitchCheckDefault">User Status</label>
                        <input class="form-check-input" name="status" type="checkbox" id="flexSwitchCheckDefault" checked />
                    </div>
                    <button type="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
        </div>

    </div>

</div>
@stop